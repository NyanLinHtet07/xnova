<?php

namespace App\Models;
use App\Models\BarData;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = [
        'name',
        'icon',
        'description'
    ];


    public function bars()
    {
        return $this->hasMany(BarData::class, 'category_id', 'id');
    }
}
